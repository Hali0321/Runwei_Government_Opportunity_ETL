#!/bin/bash

echo "🧹 SMART AZURE GRANTS PIPELINE CLEANUP"
echo "======================================"
echo "📅 Started: $(date)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

PROJECT_ROOT=$(pwd)
echo "📍 Project root: $PROJECT_ROOT"

# Create backup before cleanup
echo -e "\n${BLUE}📦 Creating backup before cleanup...${NC}"
BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
tar -czf "$BACKUP_DIR/full_backup.tar.gz" . --exclude="$BACKUP_DIR" --exclude="*.log" --exclude="__pycache__" 2>/dev/null
echo "✅ Backup created: $BACKUP_DIR/full_backup.tar.gz"

echo -e "\n${BLUE}🔍 ANALYZING PROJECT FILES${NC}"
echo "=========================="

# Count current files
TOTAL_FILES=$(find . -type f \( -name "*.py" -o -name "*.sh" -o -name "*.sql" -o -name "*.md" -o -name "*.json" \) | wc -l)
echo "📊 Found $TOTAL_FILES project files"

echo -e "\n${GREEN}✅ ESSENTIAL FILES TO KEEP${NC}"
echo "=========================="

echo "🎯 Core Pipeline Files:"
find . -name "*complete*pipeline*" -type f | grep -v "__pycache__" | head -5
find . -name "*layer2*enhancement*" -type f | grep -v "__pycache__" | head -3
find . -name "*layer3*" -type f | grep -v "__pycache__" | head -3

echo -e "\n🔧 Configuration Files:"
find . -name "*config*" -type f | grep -v "__pycache__"
find . -name "requirements.txt" -type f
find . -name ".env*" -type f

echo -e "\n📚 Documentation:"
find . -name "README.md" -type f
find . -name "*.md" -type f | grep -i "architecture\|pipeline\|installation"

echo -e "\n${RED}❌ FILES TO DELETE${NC}"
echo "================="

echo "🗑️ Log files:"
find . -name "*.log" -type f | wc -l | xargs echo "  Log files found:"

echo -e "\n🗑️ Old/backup versions:"
find . -name "*old*" -o -name "*backup*" -o -name "*_v[0-9]*" -type f | wc -l | xargs echo "  Old version files:"

echo -e "\n🗑️ Duplicate/similar files:"
echo "  Files with 'layer2' in name:"
find . -name "*layer2*" -type f | wc -l | xargs echo "    "
echo "  Files with 'enhancement' in name:"
find . -name "*enhancement*" -type f | wc -l | xargs echo "    "

echo -e "\n${YELLOW}⚠️ RECOMMENDED CLEANUP ACTIONS${NC}"
echo "=============================="

cat << 'ACTIONS'
KEEP THESE ESSENTIAL FILES:
✅ comprehensive_layer2_enhancement_fixed.py (main Layer 2)
✅ complete_grants_pipeline.py (main orchestrator)
✅ collect_grants_from_website.py (data collection)
✅ import_storage_to_layer1.py (Azure sync)
✅ requirements.txt
✅ database_config.json
✅ Main README.md files

DELETE THESE FILE TYPES:
❌ All *.log files
❌ Files with '_old', '_backup', '_v1', etc.
❌ Duplicate layer2 enhancement scripts (keep only the fixed version)
❌ Archive/old_versions folder contents (if properly backed up)
❌ __pycache__ directories
❌ Temporary SQL files (*_temp.sql, batch_*.sql)

ORGANIZE INTO CLEAN STRUCTURE:
📁 production/
   ├── scripts/ (main pipeline files)
   ├── config/ (configuration files)
   └── docs/ (documentation)
📁 utilities/ (helper scripts)
📁 archive/ (old versions - temporary)
📁 logs/ (generated logs - gitignored)
ACTIONS

echo -e "\n${PURPLE}🤖 AUTOMATED CLEANUP${NC}"
echo "==================="

read -p "Do you want me to perform automated cleanup? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🚀 Starting automated cleanup..."
    
    # Create clean directory structure
    echo "📁 Creating clean directory structure..."
    mkdir -p production/{scripts,config,docs}
    mkdir -p utilities
    mkdir -p archive/old_versions
    mkdir -p logs
    
    # Move essential files to production
    echo "📦 Moving essential files..."
    
    # Main pipeline files
    [ -f "comprehensive_layer2_enhancement_fixed.py" ] && mv "comprehensive_layer2_enhancement_fixed.py" "production/scripts/layer2_enhancement.py"
    [ -f "complete_grants_pipeline.py" ] && mv "complete_grants_pipeline.py" "production/scripts/"
    
    # Data collection
    find . -maxdepth 1 -name "*collect*grants*" -type f -exec mv {} production/scripts/ \; 2>/dev/null
    find . -maxdepth 1 -name "*import*storage*" -type f -exec mv {} production/scripts/ \; 2>/dev/null
    
    # Configuration
    [ -f "database_config.json" ] && mv "database_config.json" "production/config/"
    [ -f "azure-deploy.json" ] && mv "azure-deploy.json" "production/config/"
    [ -f "requirements.txt" ] && mv "requirements.txt" "production/"
    
    # Documentation
    [ -f "README.md" ] && cp "README.md" "production/docs/"
    find . -maxdepth 1 -name "*installation*" -o -name "*examples*" -type f -exec mv {} production/docs/ \; 2>/dev/null
    
    # Move utilities
    find . -maxdepth 1 -name "*test*" -o -name "*check*" -o -name "*status*" -type f -exec mv {} utilities/ \; 2>/dev/null
    
    # Archive old versions
    find . -maxdepth 1 \( -name "*old*" -o -name "*backup*" -o -name "*_v[0-9]*" \) -type f -exec mv {} archive/old_versions/ \; 2>/dev/null
    
    # Move archive folder contents
    [ -d "archive" ] && find archive -name "*.py" -exec mv {} archive/old_versions/ \; 2>/dev/null
    
    # Clean up logs
    find . -name "*.log" -type f -exec mv {} logs/ \; 2>/dev/null
    
    # Remove empty directories
    find . -type d -empty -delete 2>/dev/null
    
    # Delete unnecessary files
    echo "🗑️ Removing unnecessary files..."
    
    # Remove log files in logs directory (keep structure)
    rm -f logs/*.log 2>/dev/null
    
    # Remove Python cache
    find . -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null
    find . -name "*.pyc" -type f -delete 2>/dev/null
    
    # Remove temporary files
    find . -name "*temp*" -o -name "*tmp*" -type f -delete 2>/dev/null
    find . -name "batch_*.sql" -type f -delete 2>/dev/null
    
    echo "✅ Automated cleanup completed"
else
    echo "ℹ️ Cleanup cancelled by user"
fi

echo -e "\n${GREEN}📊 CLEANUP SUMMARY${NC}"
echo "=================="

NEW_TOTAL=$(find . -type f \( -name "*.py" -o -name "*.sh" -o -name "*.sql" -o -name "*.md" -o -name "*.json" \) | wc -l)
REMOVED=$((TOTAL_FILES - NEW_TOTAL))

echo "📈 Files before cleanup: $TOTAL_FILES"
echo "📉 Files after cleanup:  $NEW_TOTAL"
echo "🗑️ Files removed:        $REMOVED"

echo -e "\n📁 New project structure:"
if [ -d "production" ]; then
    echo "production/"
    find production -type f | head -10 | sed 's/^/  /'
    [ $(find production -type f | wc -l) -gt 10 ] && echo "  ... and $(( $(find production -type f | wc -l) - 10 )) more files"
fi

if [ -d "utilities" ]; then
    echo "utilities/"
    find utilities -type f | head -5 | sed 's/^/  /'
fi

echo -e "\n${GREEN}🎯 NEXT STEPS${NC}"
echo "============"
echo "1. Review the organized files in production/ directory"
echo "2. Test your main pipeline: python production/scripts/complete_grants_pipeline.py"
echo "3. Update any import paths in your scripts"
echo "4. Commit to Git: git add . && git commit -m 'Organized project structure'"
echo "5. Remove backup if everything works: rm -rf $BACKUP_DIR"

echo -e "\n✅ Project cleanup completed!"
echo "🔄 Your Azure grants pipeline is now organized and production-ready!"

