# Installation Guide

## Prerequisites

### System Requirements
- **Python**: 3.8 or higher
- **Operating System**: Windows 10+, macOS 10.15+, or Linux
- **Memory**: 4GB RAM minimum
- **Storage**: 1GB free space

### Azure Requirements
- Azure subscription
- Azure SQL Database (Basic tier sufficient)
- Azure Storage Account (General Purpose v2)

## Step-by-Step Installation

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/azure-grants-pipeline.git
cd azure-grants-pipeline
```

### 2. Python Environment
```bash
# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (macOS/Linux)  
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Chrome Setup
```bash
# Install ChromeDriver automatically
pip install webdriver-manager
```

Or download manually from [ChromeDriver](https://chromedriver.chromium.org/)

### 4. Azure Configuration

#### Create Azure Resources
```bash
# Login to Azure
az login

# Create resource group
az group create --name grants-pipeline-rg --location eastus

# Create storage account
az storage account create \
  --name grantsstorage$(date +%s) \
  --resource-group grants-pipeline-rg \
  --location eastus \
  --sku Standard_LRS

# Create SQL Database
az sql server create \
  --name grants-sql-server \
  --resource-group grants-pipeline-rg \
  --location eastus \
  --admin-user grantsadmin \
  --admin-password 'YourSecurePassword123!'

az sql db create \
  --resource-group grants-pipeline-rg \
  --server grants-sql-server \
  --name GrantsGovDB \
  --service-objective Basic
```

### 5. Database Configuration
```bash
# Copy configuration template
cp config/samples/database_config.sample config/database_config.py

# Edit with your Azure SQL details
nano config/database_config.py
```

### 6. Test Installation
```bash
# Test pipeline
python src/pipeline/grants_pipeline.py --test

# Expected output: "✅ All systems ready"
```

## Troubleshooting

### Common Issues

**ChromeDriver not found**
```bash
pip install --upgrade webdriver-manager
```

**Azure connection timeout**
- Check firewall rules on Azure SQL
- Verify connection string format

**Permission denied on temp directory**
```bash
sudo chmod 755 /tmp
```

## Next Steps

- [Usage Examples](../usage/examples.md)
- [Azure Deployment](azure-deployment.md)
- [API Reference](../api/database-schema.md)
