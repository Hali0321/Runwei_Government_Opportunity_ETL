# Usage Examples

## Basic Usage

### Run Complete Pipeline
```python
from src.pipeline.grants_pipeline import CompleteGrantsPipeline

# Initialize pipeline
pipeline = CompleteGrantsPipeline()

# Run all steps
success = pipeline.run_complete_pipeline()

if success:
    print("✅ Pipeline completed successfully!")
else:
    print("❌ Pipeline failed - check logs")
```

### Run Individual Steps
```python
# Step 1: Collect from Grants.gov
pipeline._step1_collect_grants()

# Step 2: Transfer to Layer 1  
pipeline._step2_transfer_to_layer1()

# Step 3: Layer 2 Enhancement
pipeline._step3_layer2_enhancement()

# Step 4: Layer 3 Selection
pipeline._step4_layer3_selection()
```

## Advanced Configuration

### Custom Search Parameters
```python
# Modify grants collection
pipeline.search_params = {
    'category': 'Education',
    'funding_type': 'Grant',
    'eligibility': 'Public'
}
```

### Quality Score Thresholds
```python
# Adjust quality filtering
pipeline.min_quality_score = 8.0  # Higher quality only
pipeline.featured_threshold = 9.5  # Premium opportunities
```

## Database Queries

### Get Latest Opportunities
```sql
SELECT TOP 10 
    Title,
    AwardValue,
    Deadline,
    IsFeatured
FROM FinalOpportunities
WHERE Deadline > GETDATE()
ORDER BY DataQualityScore DESC;
```

### Filter by Category
```sql
SELECT *
FROM FinalOpportunities  
WHERE Industry = 'Education'
  AND CashAward > 50000
  AND IsFeatured = 1;
```

### Export to JSON
```python
import json
import pyodbc

def export_opportunities_to_json():
    conn = pyodbc.connect(
        f"DRIVER={{ODBC Driver 18 for SQL Server}};"
        f"SERVER={server};DATABASE={database};"
        f"UID={username};PWD={password}"
    )
    
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM FinalOpportunities")
    
    columns = [desc[0] for desc in cursor.description]
    results = []
    
    for row in cursor.fetchall():
        results.append(dict(zip(columns, row)))
    
    with open('grants_export.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"✅ Exported {len(results)} opportunities")
```

## Automation Examples

### Cron Job Setup
```bash
# Edit crontab
crontab -e

# Add daily execution at 6 AM
0 6 * * * cd /path/to/azure-grants-pipeline && python src/pipeline/grants_pipeline.py >> logs/daily.log 2>&1
```

### Azure Functions Integration
```python
import azure.functions as func
from src.pipeline.grants_pipeline import CompleteGrantsPipeline

def main(mytimer: func.TimerRequest) -> None:
    pipeline = CompleteGrantsPipeline()
    success = pipeline.run_complete_pipeline()
    
    if success:
        logging.info("✅ Daily pipeline completed")
    else:
        logging.error("❌ Daily pipeline failed")
```

### Power Automate Integration
```json
{
    "definition": {
        "triggers": {
            "Recurrence": {
                "recurrence": {
                    "frequency": "Day",
                    "interval": 1,
                    "startTime": "2023-01-01T06:00:00Z"
                }
            }
        },
        "actions": {
            "HTTP": {
                "type": "Http",
                "inputs": {
                    "method": "POST",
                    "uri": "https://your-function-app.azurewebsites.net/api/run-pipeline"
                }
            }
        }
    }
}
```

## Error Handling

### Retry Logic
```python
import time
from typing import Optional

def run_with_retry(max_attempts: int = 3) -> bool:
    for attempt in range(max_attempts):
        try:
            pipeline = CompleteGrantsPipeline()
            return pipeline.run_complete_pipeline()
        except Exception as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            if attempt < max_attempts - 1:
                time.sleep(60)  # Wait 1 minute before retry
            else:
                return False
```

### Health Checks
```python
def check_pipeline_health() -> dict:
    """Check pipeline component health"""
    health = {
        'azure_storage': False,
        'sql_database': False,
        'grants_website': False
    }
    
    try:
        # Test Azure Storage
        pipeline = CompleteGrantsPipeline()
        pipeline.table_client.get_entity("Grant", "test")
        health['azure_storage'] = True
    except:
        pass
    
    try:
        # Test SQL Database
        result = pipeline._execute_sql("SELECT 1")
        health['sql_database'] = bool(result)
    except:
        pass
    
    try:
        # Test Grants.gov accessibility
        import requests
        response = requests.get("https://www.grants.gov", timeout=10)
        health['grants_website'] = response.status_code == 200
    except:
        pass
    
    return health
```

## Performance Optimization

### Batch Processing
```python
# Process larger batches for better performance
pipeline.batch_size = 50  # Increase from default 25
pipeline.parallel_workers = 4  # Use multiple threads
```

### Memory Management
```python
# Clear data between steps
import gc

def run_optimized_pipeline():
    pipeline = CompleteGrantsPipeline()
    
    # Step 1
    pipeline._step1_collect_grants()
    gc.collect()  # Free memory
    
    # Step 2  
    pipeline._step2_transfer_to_layer1()
    gc.collect()
    
    # Continue...
```
